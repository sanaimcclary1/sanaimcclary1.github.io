This assignment uses HTML and CSS to build a website that jumps through three different pages.
These pages include an index, introduction, and little prince page. 
